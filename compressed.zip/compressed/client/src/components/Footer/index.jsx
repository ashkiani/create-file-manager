import React from 'react'

export default function index() {
    return (
        <div className="fixed-bottom bg-info text-white text-center">
            <small>&copy; Copyright 2020, Siavash Ashkiani</small>
        </div>
    )
}
