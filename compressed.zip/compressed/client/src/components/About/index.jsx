import React from 'react'

export default function index() {
    return (
        <div>
            <div className="container">
                <h1>About</h1>
            </div>
        </div>
    )
}
