import React from 'react'

export default function index() {
    return (
        <div className="container">
            <h1>Help</h1>
        </div>
    )
}
