# file-manager-auth-mern
Boilerplate for Password Protected File Manager Apps with MERN
